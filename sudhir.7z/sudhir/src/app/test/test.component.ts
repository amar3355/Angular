import { Component, OnInit } from '@angular/core';
import { DummyuserService } from '../dummyuser.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  em: any=[];
  constructor(private service:DummyuserService) { }

  ngOnInit(): void {
   
  }

  searchbyage(value: any){
  
    return this.service.getemployeeage(value).subscribe(em=>{
    
     this.em=em;
   })
  }
  

}
