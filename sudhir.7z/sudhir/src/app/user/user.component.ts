import { Component, OnInit } from '@angular/core';
import { DummyuserService } from '../dummyuser.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  data:any =[];
  constructor(private user:DummyuserService) { 
    this.user.grtdata().subscribe(data=>{
     // console.warn(data)
      this.data=data
    })
    
  }

  ngOnInit(): void {
  }

}
