import { formatCurrency } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { DummyuserService } from '../dummyuser.service';

@Component({
  selector: 'app-submit-form',
  templateUrl: './submit-form.component.html',
  styleUrls: ['./submit-form.component.css']
})
export class SubmitFormComponent implements OnInit {
  name1:any
  name2:any
  name3:any
  name4:any
  constructor(private http:HttpClient) { 
  
    }
    
  onSubmit(data: any)
{  //console.log(data)
 // const newData= {name:data.value.name, id:data.value.id, age:data.value.age, salary:data.value.salary}
  var url='http://localhost:8082/api/save'
  this.http.post(url , data).subscribe((result)=>{console.warn(result)})
  this.name1=data.name
  this.name2=data.age
  console.log( this.name2)
this.name3=data.salary
this.name4=data.id
  
}


  ngOnInit(): void { }


}
