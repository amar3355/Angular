import { Component, Input, OnInit } from '@angular/core';

import { DummyuserService } from '../dummyuser.service';
import{HeaderComponent } from '../header/header.component'
@Component({
  selector: 'app-searchage',
  templateUrl: './searchage.component.html',
  styleUrls: ['./searchage.component.css']
})
export class SearchageComponent implements OnInit {
  em: any=[];


  constructor(private service:DummyuserService) { 

  }

  ngOnInit(): void {
    this.service.ageData.subscribe((data)=>{
      this.em=data
      console.log(this.em)
      
    })


  }


 
  
  
}



