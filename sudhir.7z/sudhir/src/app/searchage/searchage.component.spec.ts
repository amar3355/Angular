import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchageComponent } from './searchage.component';

describe('SearchageComponent', () => {
  let component: SearchageComponent;
  let fixture: ComponentFixture<SearchageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
