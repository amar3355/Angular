import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import {NgbPanelChangeEvent} from '@ng-bootstrap/ng-bootstrap';
import { DummyuserService } from '../dummyuser.service';
import { employee } from '../employee';


@Component({
  selector: 'app-boot-demo',
  templateUrl: './boot-demo.component.html',
  styleUrls: ['./boot-demo.component.css']
})
export class BootDemoComponent implements OnInit {
  alert:boolean=false;
  emp1:employee=new employee();
 

  addemployee= new FormGroup(
    {
      name: new FormControl(''),
      salary: new FormControl(''),
      age: new FormControl('')
    }
  )
  constructor(private service:DummyuserService) { }

  ngOnInit(): void {
  }

  createemployee()
  {
   //  console.warn(this.addemployee.value)
   //
   this.emp1=this.addemployee.value
   console.log("Befor")
   console.log(this.emp1)
   this.service.addemployee(this.emp1).subscribe((result)=>
   { this.alert=true
    console.log("after subscription")
   console.log(result) })
      
  }

  

  closeAlert(){
this.alert=false
  }

}
