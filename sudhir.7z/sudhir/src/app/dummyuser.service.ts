import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { employee } from './employee';


@Injectable({
  providedIn: 'root'
})
export class DummyuserService {
   employee='http://localhost:8082/api/save'
   url = 'https://jsonplaceholder.typicode.com/todos'
   emp='http://localhost:8082/api/all'
  constructor(private http:HttpClient ) { }

  grtdata(){

   
    return this.http.get(this.url);
  }

  getemployee()
  {
    
    return this.http.get(this.emp);
  }
addemployee(data: any): Observable<Object>{
  console.log("Service")
 console.log( data)
  return this.http.post(`${this.employee}`, data )
}
 
getemployeeage(age: any)
{
  return this.http.get(`${this.emp}/${age}`)
}
  ageData = new Subject<any>(); 

}
