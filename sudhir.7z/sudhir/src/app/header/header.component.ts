import { Component, OnInit } from '@angular/core';
import { DummyuserService } from '../dummyuser.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  active = "";
  emp:any=[];

  
  constructor(private service:DummyuserService) { }

  ngOnInit(): void {
    
   
     
  }

 
  searchbyage(value: any){
  
    this.service.getemployeeage(value).subscribe(em=>{
     this.emp=em;
     this.service.ageData.next(this.emp)
    
   })
  
  }

}
