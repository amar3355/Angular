
export class employee{
   
    name:string | undefined;
   
    salary: string | undefined;
    age: string | undefined;
   
 }


