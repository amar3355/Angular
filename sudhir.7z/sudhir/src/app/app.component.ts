import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-Demo';
  name ='aMar kUMar'
  col= "red";
  
  updatecol(){
    this.col ="green"
  }
  public isCollapsed = false;
}
