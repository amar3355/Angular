import { Component, OnInit } from '@angular/core';
import { DummyuserService } from '../dummyuser.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  model = {
    left: true,
    middle: false,
    right: false
  };
em:any=[];
  constructor(private emp:DummyuserService) 
  {
     emp.getemployee().subscribe(em=>{
       console.warn(em) 
       this.em=em;
     })

   }

  ngOnInit(): void {
  }

}
