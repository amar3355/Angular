import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UserComponent } from './user/user.component';
import {HttpClientModule} from '@angular/common/http';
import { SubmitFormComponent } from './submit-form/submit-form.component';
import {Form, FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BootDemoComponent } from './boot-demo/boot-demo.component';
import { TestComponent } from './test/test.component';
import { FastComponent } from './fast/fast.component';
import { PeriodicComponent } from './periodic/periodic.component';
import { SudhirComponent } from './sudhir/sudhir.component'
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    UserComponent,
    SubmitFormComponent,
    BootDemoComponent,
   
    TestComponent,
    FastComponent,
    PeriodicComponent,
    SudhirComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
