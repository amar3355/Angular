export class Employee1 {
    id: number| undefined;
    firstName: string | undefined;
    lastName: string | undefined;
    emailId: string| undefined;
}