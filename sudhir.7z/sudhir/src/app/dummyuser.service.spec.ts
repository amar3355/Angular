import { TestBed } from '@angular/core/testing';

import { DummyuserService } from './dummyuser.service';

describe('DummyuserService', () => {
  let service: DummyuserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DummyuserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
