
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'hello',
  templateUrl: 'periodic.component.html',
  styles: [`h1 { font-family: Lato; }`]
})
export class PeriodicComponent implements OnInit {
  @Input() name: string | undefined;

  isOpen = false;
  isDropdownOpen = false;
  constructor() { }

  ngOnInit() {
   
  }

  toggleNavbar() {
    this.isOpen = !this.isOpen;
  }

  toggleDropDown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

}
