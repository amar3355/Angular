import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-fast',
  templateUrl: './fast.component.html',
  styleUrls: ['./fast.component.css']
})
export class FastComponent implements OnInit {
  name1: any
  name2: any
  name3: any
  name4: any
  toggleOn = false
  fastForm = new FormGroup(
    {
      name: new FormControl(''),
      email: new FormControl(''),
      message: new FormControl(''),
      subject: new FormControl('')
    }
  )

  constructor() { }

  isValid: boolean = true;
  age: number = 12;
  changeValue(valid: boolean) {
    this.isValid = valid;
  }

  red() {


  }
  onSubmit(data: FormGroup) {
    this.name1 = data.value.name
    this.name2 = data.value.email
    this.name4 = data.value.message
    this.name3 = data.value.subject
    console.log(this.name1, this.name2)
    console.log(data)
    this.toggleOn = true
  }
  ngOnInit(): void {
  }

}
