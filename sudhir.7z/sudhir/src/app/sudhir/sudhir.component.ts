import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sudhir',
  templateUrl: './sudhir.component.html',
  styleUrls: ['./sudhir.component.css']
})
export class SudhirComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
